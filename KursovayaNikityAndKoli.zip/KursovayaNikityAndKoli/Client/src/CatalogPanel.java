import Authorization.AuthorizationDialog;
import Authorization.Reg2Dialog;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CatalogPanel extends JPanel {
    private static int category = 0;
    static final DefaultListModel dfm = new DefaultListModel<>();
    static JList list;
    AuthorizationDialog dialog0;
    public static void event(AuthorizationDialog dialog0) throws SQLException {
        dialog0 = new AuthorizationDialog();
        dialog0.setVisible(true);
        if (dialog0.getEvent() == 1)
        {
            dialog0.setVisible(false);
            EntranceDialog entrance = new EntranceDialog();
            entrance.setVisible(true);
            if (entrance.getFlag() == 2){
                category = 1;
                dialog0.dispose();
            }
            else if (entrance.getFlag() == 1) {
                dialog0.setEvent(0);
                event(dialog0);
            }
        } else if (dialog0.getEvent() == 2) {
            dialog0.setVisible(false);
            Reg1Dialog reg = new Reg1Dialog();
            reg.setVisible(true);

            if (reg.getFlag() == 2)
            {
                    reg.setVisible(false);
                    Reg2Dialog reg2 = new Reg2Dialog();
                    reg2.setVisible(true);
                    if (reg2.getFlag() == 2){
                        category = 1;
                        reg.dispose();
                        dialog0.dispose();
                    }
                    else if (reg.getFlag() == 1) {
                        reg.setVisible(true);
                    }
            }
            else if (reg.getFlag() == 1) {
                dialog0.setEvent(0);
                event(dialog0);
            }
        }
    }
    public CatalogPanel() throws SQLException {
        event(dialog0);

        if (category == 0)
        {
            JPanel leftPanel = new JPanel(new BorderLayout());
            {
                JPanel leftHighPanel = new JPanel();
                leftHighPanel.setBackground(Color.LIGHT_GRAY);
                leftHighPanel.add(new JLabel("������� ������� "));
                leftPanel.add(leftHighPanel, BorderLayout.NORTH);
                dfm.clear();
                ResultSet result = Products.getNamesGoods();
                while (result.next()){
                    dfm.addElement(result.getString("name"));
                }
                list = new JList(dfm);
                JScrollPane listScroll = new JScrollPane(list);
                leftPanel.add(listScroll, BorderLayout.CENTER);
            }

            JPanel rightPanel = new JPanel(new BorderLayout());
            {
                JButton showInfoButton = new JButton("�������� ����������");
                JButton deleteInfoButton = new JButton("�������� ����");

                JToolBar toolBarRight = new JToolBar();
                toolBarRight.setFloatable(false);
                toolBarRight.add(showInfoButton);
                rightPanel.add(toolBarRight, BorderLayout.NORTH);
                showInfoButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        rightPanel.removeAll();
                        JPanel rightNorthPanel = new JPanel(new BorderLayout());
                        rightNorthPanel.add(toolBarRight, BorderLayout.NORTH);
                        if (list.getSelectedValue() != null) {
                            JPanel rightHighPanel = new JPanel(new BorderLayout());

                            rightHighPanel.setBackground(Color.LIGHT_GRAY);
                            ResultSet goodsPrice= null;
                            try {
                                goodsPrice = Products.getPrice((String) list.getSelectedValue());
                            } catch (SQLException ex) {
                                throw new RuntimeException(ex);
                            }
                            {
                                JPanel price_field = new JPanel();
                                price_field.add(new JLabel("����: "));
                                JTextField price_text = new JTextField();
                                try {
                                    while (goodsPrice.next()){
                                        price_text.setText(Double.toString(goodsPrice.getDouble("price")));
                                    }
                                } catch (SQLException ex) {
                                    throw new RuntimeException(ex);
                                }

                                price_text.setEditable(false);
                                price_field.add(price_text);
                                price_field.add(new JLabel("���./�.�."));
                                rightHighPanel.add(price_field, BorderLayout.WEST);
                            }

                            rightNorthPanel.add(rightHighPanel, BorderLayout.SOUTH);
                            rightPanel.add(rightNorthPanel, BorderLayout.NORTH);
                            JPanel desc_panel = new JPanel(new BorderLayout());
                            JPanel descHighPanel = new JPanel(new BorderLayout());
                            ResultSet goodsAvaibility = null;
                            try {
                                goodsAvaibility = Products.getAvaibility((String) list.getSelectedValue());
                            } catch (SQLException ex) {
                                throw new RuntimeException(ex);
                            }
                            {
                                descHighPanel.add(new JLabel("�������� ������: "), BorderLayout.WEST);
                                JPanel avaibility_field = new JPanel(new FlowLayout());
                                avaibility_field.add(new JLabel("�������: "));
                                String avaibility_str = null;
                                try {
                                    while (goodsAvaibility.next()){
                                        avaibility_str = goodsAvaibility.getString("avaibility");

                                    }
                                } catch (SQLException ex) {
                                    throw new RuntimeException(ex);
                                }
                                JTextField avaibility_text = new JTextField(avaibility_str);
                                avaibility_text.setEditable(false);
                                avaibility_field.add(avaibility_text);
                                descHighPanel.add(avaibility_field, BorderLayout.EAST);
                            }
                            desc_panel.add(descHighPanel, BorderLayout.NORTH);
                            ResultSet goodsDesc = null;
                            try {
                                goodsDesc = Products.getDescription((String) list.getSelectedValue());
                            } catch (SQLException ex) {
                                throw new RuntimeException(ex);
                            }
                            JTextArea desc = null;
                            try {
                                goodsDesc.next();
                                desc = new JTextArea(goodsDesc.getString("description"));
                            } catch (SQLException ex) {
                                throw new RuntimeException(ex);
                            }
                            desc.setEditable(false);
                            desc_panel.add(desc);
                            rightPanel.add(desc_panel, BorderLayout.CENTER);

//                            if (list.getSelectedValue().equals("����")) {
//                                rightPanel.add(new JLabel("���� ��������"));
//                            }
//                            if (list.getSelectedValue().equals("�����")) {
//                                rightPanel.add(new JLabel("����� � �**�"));
//                            }
                        }
                    }
                });
//                JPanel rightHighPanel = new JPanel(new BorderLayout());
//                rightHighPanel.setBackground(Color.LIGHT_GRAY);
//                {
//                    JPanel id_field = new JPanel(new FlowLayout());
//                    id_field.add(new JLabel("ID ������: "));
//                    String id_str = String.valueOf(product.getId());
//                    JTextField id_text = new JTextField(id_str);
//                    id_text.setEditable(false);
//                    id_field.add(id_text);
//                    rightHighPanel.add(id_field, BorderLayout.WEST);
//                }
//                {
//                    JPanel price_field = new JPanel();
//                    price_field.add(new JLabel("����: "));
//                    JTextField price_text = new JTextField(String.valueOf(product.getPrice()));
//                    price_text.setEditable(false);
//                    price_field.add(price_text);
//                    price_field.add(new JLabel("���./�.�."));
//                    rightHighPanel.add(price_field, BorderLayout.EAST);
//                }
//                rightPanel.add(rightHighPanel, BorderLayout.NORTH);
//                JPanel desc_panel = new JPanel(new BorderLayout());
//                JPanel descHighPanel = new JPanel(new BorderLayout());
//                    {
//                        descHighPanel.add(new JLabel("�������� ������: "), BorderLayout.WEST);
//                        JPanel avaibility_field = new JPanel(new FlowLayout());
//                        avaibility_field.add(new JLabel("�������: "));
//                        String avaibility_str = String.valueOf(product.getAvaibility());
//                        JTextField avaibility_text = new JTextField(avaibility_str);
//                        avaibility_text.setEditable(false);
//                        avaibility_field.add(avaibility_text);
//                        descHighPanel.add(avaibility_field, BorderLayout.EAST);
//                    }
//                    desc_panel.add(descHighPanel, BorderLayout.NORTH);
//                    JTextArea desc = new JTextArea(product.getDescription());
//                    desc.setEditable(false);
//                    desc_panel.add(desc);
//                rightPanel.add(desc_panel, BorderLayout.CENTER);
            }

            JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftPanel, rightPanel);

            splitPane.setDividerLocation(200);

            setLayout(new BorderLayout());
            add(splitPane, BorderLayout.CENTER);
        }
        else {
            {
                JPanel leftPanel = new JPanel(new BorderLayout());
                {
                    JPanel leftHighPanel = new JPanel();
                    leftHighPanel.setBackground(Color.LIGHT_GRAY);
                    leftHighPanel.add(new JLabel("������� ������� "));
                    leftPanel.add(leftHighPanel, BorderLayout.NORTH);
                    dfm.clear();
                    ResultSet result = Products.getNamesGoods();
                    while (result.next()){
                        dfm.addElement(result.getString("name"));
                    }
                    list = new JList(dfm);
                    JScrollPane listScroll = new JScrollPane(list);
                    leftPanel.add(listScroll, BorderLayout.CENTER);
                    JToolBar leftToolBar = new JToolBar();
                    JButton addProduct = new JButton("��������");
                    JButton delProduct = new JButton("�������");
                    leftToolBar.add(addProduct);
                    leftToolBar.add(delProduct);
                    leftToolBar.setFloatable(false);
                    leftPanel.add(leftToolBar, BorderLayout.SOUTH);

                    addProduct.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            AddDialog addDialog = new AddDialog();
                            addDialog.setVisible(true);
                            if (addDialog.isFlag())
                                dfm.addElement(addDialog.getProductName());
                            addDialog.setFlag(false);
                        }
                    });

                    delProduct.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            if (list.getSelectedValue() != null){
                                DelDialog delDialog = new DelDialog();
                                delDialog.setName((String) list.getSelectedValue());
                                delDialog.setVisible(true);

                                if (delDialog.isFlag()){
                                    dfm.removeElement(list.getSelectedValue());
                                }
                                delDialog.setFlag(false);
                            }
                        }
                    });
                }

                JPanel rightPanel = new JPanel(new BorderLayout());
                {
                    JButton showInfoButton = new JButton("�������� ����������");

                    JToolBar toolBarRight = new JToolBar();
                    toolBarRight.setFloatable(false);
                    toolBarRight.add(showInfoButton);
                    rightPanel.add(toolBarRight, BorderLayout.NORTH);
                    showInfoButton.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            rightPanel.removeAll();
                            JPanel rightNorthPanel = new JPanel(new BorderLayout());
                            rightNorthPanel.add(toolBarRight, BorderLayout.NORTH);
                            if (list.getSelectedValue() != null) {
                                JPanel rightHighPanel = new JPanel(new BorderLayout());

                                rightHighPanel.setBackground(Color.LIGHT_GRAY);
                                ResultSet goodsPrice= null;
                                try {
                                    goodsPrice = Products.getPrice((String) list.getSelectedValue());
                                } catch (SQLException ex) {
                                    throw new RuntimeException(ex);
                                }
                                {
                                    JPanel price_field = new JPanel();
                                    price_field.add(new JLabel("����: "));
                                    JTextField price_text = new JTextField();
                                    try {
                                        while (goodsPrice.next()){
                                            price_text.setText(Double.toString(goodsPrice.getDouble("price")));
                                        }
                                    } catch (SQLException ex) {
                                        throw new RuntimeException(ex);
                                    }

                                    price_text.setEditable(false);
                                    price_field.add(price_text);
                                    price_field.add(new JLabel("���./�.�."));
                                    rightHighPanel.add(price_field, BorderLayout.WEST);
                                }

                                rightNorthPanel.add(rightHighPanel, BorderLayout.SOUTH);
                                rightPanel.add(rightNorthPanel, BorderLayout.NORTH);
                                JPanel desc_panel = new JPanel(new BorderLayout());
                                JPanel descHighPanel = new JPanel(new BorderLayout());
                                ResultSet goodsAvaibility = null;
                                try {
                                    goodsAvaibility = Products.getAvaibility((String) list.getSelectedValue());
                                } catch (SQLException ex) {
                                    throw new RuntimeException(ex);
                                }
                                {
                                    descHighPanel.add(new JLabel("�������� ������: "), BorderLayout.WEST);
                                    JPanel avaibility_field = new JPanel(new FlowLayout());
                                    avaibility_field.add(new JLabel("�������: "));
                                    String avaibility_str = null;
                                    try {
                                        while (goodsAvaibility.next()){
                                            avaibility_str = goodsAvaibility.getString("avaibility");

                                        }
                                    } catch (SQLException ex) {
                                        throw new RuntimeException(ex);
                                    }
                                    JTextField avaibility_text = new JTextField(avaibility_str);
                                    avaibility_text.setEditable(false);
                                    avaibility_field.add(avaibility_text);
                                    descHighPanel.add(avaibility_field, BorderLayout.EAST);
                                }
                                desc_panel.add(descHighPanel, BorderLayout.NORTH);
                                ResultSet goodsDesc = null;
                                try {
                                    goodsDesc = Products.getDescription((String) list.getSelectedValue());
                                } catch (SQLException ex) {
                                    throw new RuntimeException(ex);
                                }
                                JTextArea desc = null;
                                try {
                                    goodsDesc.next();
                                    desc = new JTextArea(goodsDesc.getString("description"));
                                } catch (SQLException ex) {
                                    throw new RuntimeException(ex);
                                }
                                desc.setEditable(false);
                                desc_panel.add(desc);
                                rightPanel.add(desc_panel, BorderLayout.CENTER);
                            }
                        }
                    });
                }

                JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftPanel, rightPanel);

                splitPane.setDividerLocation(200);

                setLayout(new BorderLayout());
                add(splitPane, BorderLayout.CENTER);
            }

        }
    }
}
