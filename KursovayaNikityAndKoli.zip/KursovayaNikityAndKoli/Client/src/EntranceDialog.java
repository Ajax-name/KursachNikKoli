import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

public class EntranceDialog extends JDialog {
    private static JFrame dialogFrame = new JFrame();
    private static int flag = 0;
    public EntranceDialog() {
        super(dialogFrame, "�����.���.����", true);
        setSize(400, 200);
        setLocationRelativeTo(null);
        setLayout(new FlowLayout());

        JPanel panel0 = new JPanel();
        JPanel panel1 = new JPanel(new FlowLayout());
        JPanel panel2 = new JPanel(new FlowLayout());
        JPanel panel3 = new JPanel(new FlowLayout());

        panel0.add(new JLabel("���� � ������� SCAM.ID"));
        panel0.setBackground(Color.WHITE);
        panel0.setSize(200, 30);

        panel1.add(new JLabel("������� ���� e-mail:"));
        JTextField email = new JTextField(20);
        panel1.add(email);
        panel1.setSize(370, 30);

        panel2.add(new JLabel("������� ���� ������:"));
        JPasswordField password = new JPasswordField(20);
        panel2.add(password);
        panel2.setSize(370, 30);

        JButton backButton = new JButton("�����");
        JButton furtherButton = new JButton("�����");

        panel3.setSize(370, 30);
        panel3.add(backButton);
        panel3.add(new JLabel("            " +
                "                               " +
                "                "));
        panel3.add(furtherButton);

        add(panel0);
        add(panel1);
        add(panel2);
        add(panel3);


        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setFlag(1);
                dispose();
            }
        });

        furtherButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String userEmail = email.getText();
                String userPassword = String.valueOf(password.getPassword());

                if (!userEmail.equals("") && !userPassword.equals(""))
                {
                    try {
                        if (Users.search_by_values(userEmail, userPassword)) {
                            setFlag(2);
                            dispose();
                        } else {
                            JPanel jPanel = new JPanel();
                            JOptionPane.showMessageDialog(jPanel, "�������� e-mail ��� ������.", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    } catch (SQLException ex) {
                        throw new RuntimeException(ex);
                    }
                } else {
                    JPanel jPanel = new JPanel();
                    JOptionPane.showMessageDialog(jPanel, "��������� ���� ������. " +
                            "����������, ���������\n �� � ������� \"�����\" ��� �����������.", "Error", JOptionPane.ERROR_MESSAGE);
                }

            }
        });
    }

    public static int getFlag() {
        return flag;
    }

    public static void setFlag(int flag) {
        EntranceDialog.flag = flag;
    }
}
