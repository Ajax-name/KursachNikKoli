import Authorization.Reg2Dialog;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

public class Reg1Dialog extends JDialog{
    private static JFrame dialogFrame = new JFrame();
    private static int flag = 0;
    private static int reg2 = 0;
    private static Users user;

    public Reg1Dialog() throws SQLException {
        super(dialogFrame, "�����.���.�����������", true);
        setSize(400, 320);
        setLocationRelativeTo(null);
        setLayout(new FlowLayout());

        JPanel panel1 = new JPanel(new FlowLayout());
        JPanel panel2 = new JPanel(new FlowLayout());
        JPanel panel3 = new JPanel(new FlowLayout());
        JPanel panel4 = new JPanel(new FlowLayout());
        JPanel panel5 = new JPanel(new FlowLayout());
        JPanel panel6 = new JPanel(new FlowLayout());
        JPanel panel7 = new JPanel(new FlowLayout());

        panel1.add(new JLabel("������� " +
                "             "));
        JTextField lastname = new JTextField(20);
        panel1.add(lastname);
        panel1.setSize(370, 30);

        panel2.add(new JLabel("��� " +
                "                       "));
        JTextField name = new JTextField(20);
        panel2.add(name);
        panel2.setSize(370, 30);

        panel3.add(new JLabel("�������� " +
                "              "));
        JTextField patronymic = new JTextField(20);
        panel3.add(patronymic);
        panel3.setSize(370, 30);

        panel4.add(new JLabel("���. ����� " +
                "          "));
        JTextField phone_num = new JTextField(20);
        panel4.add(phone_num);
        panel4.setSize(370, 30);

        panel5.add(new JLabel("����� ��. �����   "));
        JTextField email = new JTextField(20);
        panel5.add(email);
        panel5.setSize(370, 30);

        panel6.add(new JLabel("������ " +
                "                  "));
        JPasswordField password = new JPasswordField(20);
        panel6.add(password);
        panel6.setSize(370, 30);

        JButton backButton = new JButton("�����");
        JButton furtherButton = new JButton("�����");

        panel7.setSize(370, 30);
        panel7.add(backButton);
        panel7.add(new JLabel("            " +
                "                               " +
                "                "));
        panel7.add(furtherButton);

        add(panel1);
        add(panel2);
        add(panel3);
        add(panel4);
        add(panel5);
        add(panel6);
        add(panel7);


        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setReg2(1);
                setFlag(1);
                dispose();
            }
        });

        furtherButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String userLastname = lastname.getText().toString();
                String userName = name.getText().toString();
                String userPatronymic = patronymic.getText().toString();
                String userPhone_num = phone_num.getText().toString();
                String userEmail = email.getText().toString();
                String userPassword = String.valueOf(password.getPassword());

                if (!userLastname.equals("") && !userName.equals("") && !userPhone_num.equals("")
                        && !userEmail.equals("") && !userPassword.equals("")){
                    user = new Users();
                    {
                        user.setName(userLastname);
                        user.setLastname(userName);
                        user.setPatronymic(userPatronymic);
                        user.setPhone_num(userPhone_num);
                        user.setEmail(userEmail);
                        user.setPassword(userPassword);
                    }

                    try {
                        user.addNewUser();
                    } catch (SQLException ex) {
                        throw new RuntimeException(ex);
                    }

                    setVisible(false);
                    Reg2Dialog reg = new Reg2Dialog();
                    reg.setVisible(true);

                    if (reg.getFlag() == 2) {
                        setFlag(2);
                        dispose();
                    }
                    else if (reg.getFlag() == 1) {
                        setVisible(true);
                    }

                } else {
                    JPanel jPanel = new JPanel();
                    JOptionPane.showMessageDialog(jPanel, "��������� ���� ������. " +
                            "����������, ���������\n �� � ������� \"�����\" ��� �����������.", "Error", JOptionPane.ERROR_MESSAGE);
                }

            }
        });
    }

    public static int getFlag() {
        return flag;
    }

    public static void setFlag(int flag) {
        Reg1Dialog.flag = flag;
    }

    public static int getReg2() {
        return reg2;
    }

    public static void setReg2(int reg2) {
        Reg1Dialog.reg2 = reg2;
    }
}
