import Authorization.Reg2Dialog;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

public class AddDialog extends JDialog {
    private static JFrame dialogFrame = new JFrame();
    private static boolean flag = false;
    private static String productName;
    public AddDialog() {
        super(dialogFrame, "���������� ������", true);
        setSize(400, 225);
        setLocationRelativeTo(null);
        setLayout(new FlowLayout());

        JPanel panel1 = new JPanel(new FlowLayout());
        JPanel panel2 = new JPanel(new FlowLayout());
        JPanel panel3 = new JPanel(new FlowLayout());
        JPanel panel4 = new JPanel(new FlowLayout());
        JPanel panel5 = new JPanel(new FlowLayout());

        panel1.add(new JLabel("��������  " +
                "             "));
        JTextField name = new JTextField(20);
        panel1.add(name);
        panel1.setSize(370, 30);

        panel2.add(new JLabel("�������� " +
                "             "));
        JTextField description = new JTextField(20);
        panel2.add(description);
        panel2.setSize(370, 30);

        panel3.add(new JLabel("���� " +
                "                      "));
        JTextField price = new JTextField(20);
        panel3.add(price);
        panel3.setSize(370, 30);

        panel4.add(new JLabel("������� " +
                "               "));
        JTextField avaibility = new JTextField(20);
        panel4.add(avaibility);
        panel4.setSize(370, 30);

        JButton backButton = new JButton("������");
        JButton furtherButton = new JButton("�����");
        panel5.add(backButton);
        panel5.add(new JLabel("            " +
                "                               " +
                "                "));
        panel5.add(furtherButton);

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

        furtherButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                productName = name.getText();
                String productDesc = description.getText();
                String productPrice = price.getText();
                String productAvaibility = avaibility.getText();

                if (!productName.equals("") && !productPrice.equals("") && !productAvaibility.equals("")){
                    setVisible(false);
                    try {
                        Products.addNewProduct(productName, productDesc, productPrice, productAvaibility);
                    } catch (SQLException ex) {
                        throw new RuntimeException(ex);
                    }
                    setProductName(productName);
                    setFlag(true);
                    dispose();
                } else {
                    JPanel jPanel = new JPanel();
                    JOptionPane.showMessageDialog(jPanel, "��������� ���� ������. " +
                            "����������, ���������\n �� � ������� \"�����\" ��� �����������.", "Error", JOptionPane.ERROR_MESSAGE);
                }

            }
        });

        add(panel1);
        add(panel2);
        add(panel3);
        add(panel4);
        add(panel5);
    }

    public static boolean isFlag() {
        return flag;
    }

    public static void setFlag(boolean flag) {
        AddDialog.flag = flag;
    }

    public static String getProductName() {
        return productName;
    }

    public static void setProductName(String productName) {
        AddDialog.productName = productName;
    }
}
