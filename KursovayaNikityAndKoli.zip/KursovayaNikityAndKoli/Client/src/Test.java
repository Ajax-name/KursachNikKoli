import java.sql.ResultSet;
import java.sql.SQLException;

public class Test {
    public static void main(String[] args) throws SQLException {

    Products.delExistProduct("������");

//        System.out.println(Users.search_by_values("alexeyyoutub@gmail.com", "password"));

//        Users user = new Users();
//        {
//            user.setName("�����");
//            user.setLastname("��������");
//            user.setPatronymic("����������");
//            user.setPhone_num("88005553535");
//            user.setEmail("noshpazaplatka@mail.ru");
//            user.setPassword("password");
//        }
//        user.addNewUser();


//        ResultSet desc = Products.getDescription("����");
//        desc.next();
//        System.out.println(desc.getString("description"));
    }
}
