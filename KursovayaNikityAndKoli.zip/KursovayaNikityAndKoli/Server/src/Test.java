import java.sql.ResultSet;

public class Test {
    public static void main(String[] args) {
        System.out.println("skjf \'");
    }
}
