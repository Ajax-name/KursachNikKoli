import java.sql.*;

public class Database {
    public static final String DB_USERNAME = "postgres";
    public static final String DB_PASSWORD = "password";
    public static final String DB_URL = "jdbc:postgresql://localhost:5432/Skamanet";

    public static Connection connection;

    static {
        try {
            connection = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    static Statement statement;

    static {
        try {
            statement = connection.createStatement();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public Database() throws SQLException {
    }

    public static ResultSet getNames (String table) throws SQLException {
        String SQL_SELECT_TABLES = "select * from " + table + " order by id";
        ResultSet result = statement.executeQuery(SQL_SELECT_TABLES);
        return result;
    }

    public static ResultSet getDescription (String table, String name) throws SQLException {
        String sql = "select * from " + table + "\nwhere name = \'" + name + "\'";
        ResultSet result = statement.executeQuery(sql);
        return result;
    }

    public static ResultSet getPrice (String table, String name) throws SQLException {
        String sql = "select * from " + table + "\nwhere name = \'" + name + "\'";
        ResultSet result = statement.executeQuery(sql);
        return result;
    }

    public static ResultSet getAvaibility (String table, String name) throws SQLException {
        String sql = "select * from " + table + "\nwhere name = \'" + name + "\'";
        ResultSet result = statement.executeQuery(sql);
        return result;
    }

    public static void addUser(String name, String lastname, String patronymic,
                               String phone_num, String email, String password) throws SQLException {
        String sql = "insert into user_data (name, lastname, patronymic, phone_num, " +
                "email, password) values (?, ?, ?, ?, ?, ?);";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1, name);
        preparedStatement.setString(2, lastname);
        preparedStatement.setString(3, patronymic);
        preparedStatement.setString(4, phone_num);
        preparedStatement.setString(5, email);
        preparedStatement.setString(6, password);
        preparedStatement.executeUpdate();
    }

    public static void addProduct(String name, String desc, String price,
                               String avaibility) throws SQLException {
        String sql = "insert into goods (name, description, price, avaibility) values (?, ?, ?, ?);";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1, name);
        preparedStatement.setString(2, desc);
        preparedStatement.setDouble(3, Double.parseDouble(price));
        preparedStatement.setInt(4, Integer.parseInt(avaibility));
        preparedStatement.executeUpdate();
    }

    public static void delProduct (String name) throws SQLException {
        String sql = "delete from goods where name = ?;";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1, name);
        preparedStatement.executeUpdate();
    }

    public static boolean Search (String email, String password) throws SQLException {
        String SQL_SELECT_TABLES = "select * from user_data order by id";
        ResultSet result = statement.executeQuery(SQL_SELECT_TABLES);
        boolean res_of_search = false;
        while (result.next())
            if (result.getString("email").equals(email) &&
                    result.getString("password").equals(password))
            {
                res_of_search = true;
                break;
            }
        return res_of_search;
    }

//    public static void main(String[] args) {
//        try {
//            connection = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
//
//            Statement statement;
//
//            try {
//                statement = connection.createStatement();
//            } catch (SQLException e) {
//                throw new RuntimeException(e);
//            }
//        } catch (SQLException e) {
//            throw new RuntimeException(e);
//        }
//    }
}
